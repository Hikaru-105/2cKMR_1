import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class createServlet2 extends HttpServlet {


    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
    	String question = request.getParameter("QUESTION");
    	String option1 = request.getParameter("QUESTION1");
    	String option2 = request.getParameter("QUESTION2");
    	String option3 = request.getParameter("QUESTION3");
    	try {
    		Class.forName("org.postgresql.Driver");
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//データベースから最新のアンケートコードを取得
    	//そのコード+1したものを作成するアンケートのコードとする
    	//分類コードに関する記述も作成者にさせる？
    	//選択肢と質問内容をデータベースに保存
    	
    	
		String url="/createSuccess.html";
		RequestDispatcher dispatcher
			=getServletContext().getRequestDispatcher(url);
		dispatcher.forward(request, response);
    }
}