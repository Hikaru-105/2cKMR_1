package db;

import java.io.Serializable;

public class createSelectBean implements Serializable{
	public void selectQreCode() throws Exception{
		String url = "jdbc:postgresql://tokushima.data.ise.shibaura-it.ac.jp";
	}
}
