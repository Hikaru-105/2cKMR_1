package db;

import java.io.Serializable;

public class createInsertBean implements Serializable{

}
